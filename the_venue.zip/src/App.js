import React from 'react';
import Header from './components/header_footer/Header'
import './resources/styles.css'
import Featured from './components/featured/Featured';
import Venue_info from './components/venue_Info/Venue_info'
import Hightlights from './components/Hightlights'
import Pricing from './components/Pricing/Pricing'
import Location from './components/Location/Location'
import Footer from './components/header_footer/Footer'
import {Element} from 'react-scroll'

function App() {
  return (
    <div className= 'App' > 
      <Header/>
      <Element name='featured'>
        <Featured/>
      </Element>

      <Element name="Venue_info">
        <Venue_info/>
      </Element>
      <Element>
        <Hightlights/>
      </Element>
      
      <Element name='pricing'>
        <Pricing/>
      </Element>
      
      <Element name='location'>
        <Location/>
      </Element>

      <Element name='footer'>
        <Footer/>
      </Element>
    </div>
  );
}

export default App;