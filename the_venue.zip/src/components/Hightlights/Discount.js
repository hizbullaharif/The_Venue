import React from "react";
import Slide from "react-reveal/Slide";
import MyButton from "../utils/MyButton";

class Discount extends React.Component {
  state = {
    discStart: 0,
    discEnd: 30,
  };

  percentage_ = () => {
    if (this.state.discStart < this.state.discEnd) {
      this.setState({
        discStart: this.state.discStart + 1,
      });
    }
  };

  componentDidUpdate() {
    setTimeout(() => {
      this.percentage_();
    }, 100);
  }

  render() {
    return (
      <div className="center_wrapper">
        <div className="discount_wrapper">
          <Slide left onReveal={() => this.percentage_()}>
            <div className="discount_porcentage">
              <span>{this.state.discStart}%</span>
              <span>OFF</span>
            </div>
          </Slide>

          <Slide right>
            <div className="discount_description">
              <h3>Purchase Tickets Before 20th June</h3>
              <p>
                Lorem Ipsum has been the industry's standard dummy text ever
                since the 1500s, when an unknown printer took a galley of type
                and scrambled it to make a type specimen book. It has survived
                not only five centuries, but also the leap into electronic
                typesetting, remaining essentially unchanged. It was popularised
                in the 1960s with the release of Letraset sheets containing
                Lorem Ipsum passages
              </p>
              <MyButton
                text="Purchase Tickets"
                bck="#ffa800"
                color="#ffffff"
                link="https://github.com/"
              />
            </div>
          </Slide>
        </div>
      </div>
    );
  }
}

export default Discount;
