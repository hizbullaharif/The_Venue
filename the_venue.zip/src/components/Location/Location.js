import React from "react";

const Location = () => {
  return (
    <div className='location_wrapper'>
      <iframe
        title='location'
        src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d13606.638124573572!2d74.312897!3d31.506041!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbbf38938d0d6b6f0!2sBlank%20Slate!5e0!3m2!1sen!2sus!4v1633961666284!5m2!1sen!2sus"
        width="100%"
        height="500px"
        style={{border:0}}
        allowfullscreen=""
      ></iframe>
      <div className='location_tag'>
        <div>Location</div>
      </div>
    </div>
  );
};

export default Location;
