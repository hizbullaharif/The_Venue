import React from 'react'
import  Drawer  from '@material-ui/core/Drawer'
import List from '@material-ui/core/List'
import ListItem from '@material-ui/core/ListItem'
import { scroller } from 'react-scroll'

 const SideDrawer = (props) => {
     const scrollToElement = (element)=>{
         scroller.scrollTo(element,{
             duration:1500,
             delay:100,
             smooth:true,
             offset: -150
         });
     }
    return (
        <div>
            <Drawer 
                anchor='right'
                open={props.open}
                onClose={()=>props.onClose(false)}
            >
            <List component='nav'>
                <ListItem button onClick={()=>scrollToElement('Venue_info')}>
                    Venue_info
                </ListItem>

                <ListItem button onClick={()=>scrollToElement('featured')}>
                    Featured
                </ListItem>

                <ListItem button onClick={()=>scrollToElement("pricing")}>
                    pricing
                </ListItem>
                
                <ListItem button onClick={()=>scrollToElement("location")}>
                    location
                </ListItem>
                
                <ListItem button onClick={()=>scrollToElement("footer")}>
                    footer
                </ListItem>
            </List>
            </Drawer>
        </div>
    )
}
export default SideDrawer