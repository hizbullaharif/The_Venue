import React from 'react'
import Slide from 'react-reveal';

import calendar_icon from '../../resources/images/icons/calendar.png'
import location_icon from '../../resources/images/icons/location.png'

const Venue_info=()=> {
    return (
        <div>
            <div className="bck_black">
                <div className="center_wrapper">
                    <div className="vn_wrapper">
                            {/* //Event item  */}
                            <Slide left duration={500}>
                        <div className="vn_item">
                            <div className="vn_outer">
                                <div className="vn_inner">
                                    <div className="vn_icon_square bck_red"></div>
                                    <div className="vn_icon"
                                         style={{
                                             background:`url(${calendar_icon})`
                                         }}
                                    ></div>
                                    <div className="vn_title">Event Date and Time</div>
                                    <div className="vn_desc">2022 jun 16</div>
                                </div>
                            </div>
                        </div>
                        </Slide>
                            {/* //Location item  */}
                            <Slide right duration={500} delay={1000}>
                            <div className="vn_item">
                            <div className="vn_outer">
                                <div className="vn_inner">
                                    <div className="vn_icon_square bck_yellow"></div>
                                    <div className="vn_icon"
                                         style={{
                                             background:`url(${location_icon})`
                                         }}
                                    ></div>
                                    <div className="vn_title">Event Location</div>
                                    <div className="vn_desc">369 DHA LAHORE,Street</div>
                                </div>
                            </div>
                        </div>
                        </Slide>
                    </div>
                </div>
            </div>
        </div>
    )
}


export default Venue_info